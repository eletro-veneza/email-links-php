<?php
session_start();

$arquivo = "dados.reg";
$usuario_admin = "admin";
$senha_admin = "admin";

// **Processo de Login**
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $user = $_POST['usuario'];
    $pass = $_POST['senha'];

    if ($user === $usuario_admin && $pass === $senha_admin) {
        $_SESSION['logado'] = true;
    } else {
        echo "<script>alert('Usuário ou senha incorretos!');</script>";
    }
}

// **Processo de Logout**
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

// **Cadastro de e-mail e link**
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email']) && isset($_POST['link']) && isset($_SESSION['logado'])) {
    $email = trim($_POST['email']);
    $link = trim($_POST['link']);

    if (!empty($email) && !empty($link)) {
        $linha = "$email|$link\n";
        file_put_contents($arquivo, $linha, FILE_APPEND);
    }
}

// **Exclusão de registros**
if (isset($_GET['excluir']) && isset($_SESSION['logado'])) {
    $indice = intval($_GET['excluir']);
    $usuarios = file_exists($arquivo) ? file($arquivo, FILE_IGNORE_NEW_LINES) : [];
    
    $usuarios = array_filter($usuarios, 'trim'); // Remove linhas vazias
    
    if (isset($usuarios[$indice])) {
        unset($usuarios[$indice]);
        file_put_contents($arquivo, implode("\n", $usuarios) . "\n");
    }
    
    header("Location: index.php");
    exit;
}

// **Lê os dados cadastrados ignorando linhas vazias**
$usuarios = file_exists($arquivo) ? file($arquivo, FILE_IGNORE_NEW_LINES) : [];
$usuarios = array_filter($usuarios, 'trim'); // Remove linhas vazias

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Administração</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 90%;
            max-width: 500px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        button:hover {
            background: #0056b3;
        }

        .logout {
            background: #dc3545;
        }

        .logout:hover {
            background: #a71d2a;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #007bff;
            color: white;
        }

        .delete-btn {
            background: #dc3545;
            padding: 5px;
            text-decoration: none;
            color: white;
            border-radius: 5px;
            display: inline-block;
        }

        .delete-btn:hover {
            background: #a71d2a;
        }

        @media (max-width: 600px) {
            table, th, td {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <?php if (!isset($_SESSION['logado'])): ?>
        <!-- Tela de Login -->
        <h2>Login</h2>
        <form method="post">
            <input type="text" name="usuario" placeholder="Usuário" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit" name="login">Entrar</button>
        </form>
        <a href="../"><button class="logout">Voltar</button></a>
    <?php else: ?>
        <!-- Painel Administrativo -->
        <h2>Painel de Administração</h2>
        <form method="post">
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="text" name="link" placeholder="URL de Download" required>
            <button type="submit">Adicionar</button>
        </form>
        <a href="?logout"><button class="logout">Sair</button></a>
        <br><br>
        <h3>Usuários Cadastrados</h3>
        <table>
            <tr>
                <th>Email</th>
                <th>Link</th>
                <th>Ação</th>
            </tr>
            <?php foreach ($usuarios as $indice => $usuario): 
                list($email, $link) = explode("|", $usuario);
            ?>
                <tr>
                    <td><?= htmlspecialchars($email) ?></td>
                    <td>
                         <a href="<?= htmlspecialchars($link) ?>" target="_blank">
                           <?= strlen($link) > 18 ? htmlspecialchars(substr($link, 0, 12)) . '...' : htmlspecialchars($link) ?>
                       </a>
                   </td>

                    <td><a class="delete-btn" href="?excluir=<?= $indice ?>" onclick="return confirm('Deseja excluir este item?');">Excluir</a></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</div>

</body>
</html>