<?php
// Arquivo com os dados
$arquivo = "adm/dados.reg";
$mensagem = "";
$links = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $emailBuscado = trim($_POST['email']);
    
    // Lê os dados ignorando linhas vazias
    $usuarios = file_exists($arquivo) ? file($arquivo, FILE_IGNORE_NEW_LINES) : [];
    $usuarios = array_filter($usuarios, 'trim');

    foreach ($usuarios as $linha) {
        list($email, $link) = explode("|", $linha);
        
        if ($email === $emailBuscado) {
            $links[] = $link;
        }
    }

    if (empty($links)) {
        $mensagem = "Nenhum link encontrado para este e-mail.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resgatar Link</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        .logo {
            width: 120px;  /* Ajuste conforme necessário */
            display: block;
            margin: 0 auto 15px; /* Centraliza a imagem */
        }


        body {
            background: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 90%;
            max-width: 500px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        input {
            width: 70%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 25%;
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #0056b3;
        }

        .links {
            margin-top: 20px;
            text-align: left;
        }

        .links a {
            display: block;
            background: #28a745;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
            margin: 5px 0;
        }

        .links a:hover {
            background: #218838;
        }

        .mensagem {
            color: red;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <img src="key.png" alt="Logo" class="logo"> <!-- Adicionando a logo -->
    <h2>Resgatar Links</h2>
    <form method="post">
        <input type="email" name="email" placeholder="Digite seu e-mail" required>
        <button type="submit">Resgatar</button>
    </form>

    <?php if (!empty($mensagem)): ?>
        <p class="mensagem"><?= htmlspecialchars($mensagem) ?></p>
    <?php endif; ?>

    <?php if (!empty($links)): ?>
        <div class="links">
            <h3>Seus links:</h3>
            <?php foreach ($links as $link): ?>
                <a href="<?= htmlspecialchars($link) ?>" target="_blank"><?= htmlspecialchars($link) ?></a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
